import '../../domain/entities/invoice_entity.dart';
import '../../domain/repositories/invoice_repository.dart';
import '../datasources/local/invoice_local_datasource.dart';
import '../models/invoice_model.dart';
import 'package:dartz/dartz.dart';

class InvoiceRepositoryImpl implements InvoiceRepository {
  final InvoiceLocalDataSource localDataSource;

  InvoiceRepositoryImpl(this.localDataSource);

  @override
  Future<Either<String, List<InvoiceEntity>>> getAllInvoices() async {
    try {
      final result = await localDataSource.getAllInvoices();
      return Right(result);
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, void>> addInvoice(InvoiceEntity invoice) async {
    try {
      final model = InvoiceModel(
        id: invoice.id,
        title: invoice.title,
        amount: invoice.amount,
      );
      await localDataSource.addInvoice(model);
      return const Right(null);
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, void>> updateInvoice(InvoiceEntity invoice) async {
    try {
      final model = InvoiceModel(
        id: invoice.id,
        title: invoice.title,
        amount: invoice.amount,
      );
      await localDataSource.updateInvoice(model);
      return const Right(null);
    } catch (e) {
      return Left(e.toString());
    }
  }

  @override
  Future<Either<String, void>> deleteInvoice(int id) async {
    try {
      await localDataSource.deleteInvoice(id);
      return const Right(null);
    } catch (e) {
      return Left(e.toString());
    }
  }
}
